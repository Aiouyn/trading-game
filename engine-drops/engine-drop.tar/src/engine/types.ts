import type { RngState } from './rng';

export type AssetClass = 'stock' | 'crypto' | 'commodity';

export type RegimeId = 'expansion' | 'overheating' | 'contraction' | 'recovery';

/** Static definition of one tradeable asset. All annual figures are per game year. */
export interface AssetDef {
  id: string;
  name: string;
  assetClass: AssetClass;
  /** sector key (stocks) or class key; assets sharing a sector share a sector factor */
  sector: string;
  initialPrice: number;
  /** used for cap-weighted indices (stocks only) */
  sharesOutstanding?: number;
  /** total annualized volatility at h = 1 in a neutral regime */
  vol: number;
  /** idiosyncratic annual log drift of fundamental value, before the regime term */
  drift: number;
  /** multiplier on the regime's equity drift (1 = moves with the market cycle, <0 = counter-cyclical) */
  cycleBeta: number;
  /** factor loadings on unit-variance shocks; normalized so that wMarket²+wSector²+wCrypto²+wIdio² = 1 */
  wMarket: number;
  wSector: number;
  wCrypto: number;
  /** half-life of the pull of price toward fundamental value, in game days */
  halfLifeDays: number;
  /** base jump intensity, jumps per game year */
  jumpsPerYear: number;
  /** mean absolute log size of up and down jumps (Kou double exponential) */
  jumpUpMean: number;
  jumpDownMean: number;
  /** probability a jump is upward in a neutral regime */
  jumpUpProb: number;
  /** price floor (hard bound, see 01 §2.2) */
  floor: number;
  /** whether the single-asset circuit breaker applies */
  circuitBreaker: boolean;
}

export interface RegimeDef {
  id: RegimeId;
  /** equity drift added to every asset's fundamental drift × cycleBeta, per game year */
  equityDrift: number;
  /** multiplier on every asset's vol */
  volMult: number;
  /** multiplier on jump intensity */
  jumpMult: number;
  /** additive shift to jumpUpProb (negative = more crashes) */
  jumpUpShift: number;
  /** crisis correlation: market loading multiplier (01 §2.1) */
  marketLoadMult: number;
  /** crisis correlation: idiosyncratic loading multiplier */
  idioMult: number;
  /** expected length in game days */
  meanDays: number;
  /** where we go when we leave this regime (probabilities sum to 1) */
  next: Partial<Record<RegimeId, number>>;
}

export interface IndexDef {
  id: string;
  name: string;
  /** asset ids; cap-weighted by sharesOutstanding */
  members: string[];
  base: number;
}

export interface WorldConfig {
  /** 1 tick = 5 real seconds; 1 market day = 1 real hour = 720 ticks */
  ticksPerDay: number;
  /** trading days per game year */
  daysPerYear: number;
  /** GARCH(1,1) on daily standardized returns */
  garchAlpha: number;
  garchBeta: number;
  garchMin: number;
  garchMax: number;
  /** Student-t degrees of freedom for idiosyncratic noise */
  studentNu: number;
  /** share of each diffusive shock and each jump that is news about value (moves V); the rest is noise that reverts */
  permanentShare: number;
  /** single-asset circuit breaker: halt after this move from the day open */
  haltThreshold: number;
  /** halt length in ticks (10 real minutes = 120 ticks) */
  haltTicks: number;
  initialRegime: RegimeId;
  regimes: Record<RegimeId, RegimeDef>;
  assets: AssetDef[];
  indices: IndexDef[];
}

export interface AssetState {
  id: string;
  /** ln market price */
  lnP: number;
  /** ln fundamental value */
  lnV: number;
  /** GARCH variance multiplier (long-run mean 1) */
  h: number;
  /** ln price at the start of the current game day */
  lnOpen: number;
  /** tick at which an active halt ends (exclusive); -1 when not halted */
  haltUntil: number;
  haltedToday: boolean;
  /** sum of today's jump log sizes; excluded from the GARCH input so jumps don't feed vol clustering */
  dayJump: number;
  /** log return accumulated while halted; applied in the reopening auction */
  pending: number;
  rng: RngState;
}

export interface RegimeChange {
  tick: number;
  from: RegimeId;
  to: RegimeId;
}

export interface WorldState {
  version: 1;
  seed: string;
  tick: number;
  regime: RegimeId;
  regimeLog: RegimeChange[];
  macroRng: RngState;
  sectorRng: Record<string, RngState>;
  assets: AssetState[];
  config: WorldConfig;
}

export interface Quote {
  assetId: string;
  price: number;
  fundamental: number;
  halted: boolean;
}

export type StepEvent =
  | { type: 'regime'; tick: number; from: RegimeId; to: RegimeId }
  | { type: 'jump'; tick: number; assetId: string; logSize: number }
  | { type: 'halt'; tick: number; assetId: string; move: number }
  | { type: 'reopen'; tick: number; assetId: string; gap: number };

export interface StepResult {
  state: WorldState;
  events: StepEvent[];
}
